# GLAM360 — Phase 1D

Inventory + Product Sales UI connected to the GLAM360 Supabase backend.

## Included
- Inventory dashboard
- Product catalogue with SKU/barcode/category/pricing
- Branch-wise stock
- Stock purchase/adjustment/return actions
- Low-stock indicators and inventory value
- Touch-friendly POS product picker
- Customer selection
- Product sale invoice creation
- Automatic stock deduction through secure Supabase RPC
- Sales & invoice history
- Print invoice / Save as PDF through browser print

## Setup
1. Copy `.env.example` to `.env`.
2. Add your Supabase project URL and **publishable key**.
3. Run `npm install`.
4. Run `npm run dev`.

Never expose a Supabase service-role/secret key in the frontend.

The Phase 1D database schema and secure RPCs are already applied to the GLAM360 Supabase project.
